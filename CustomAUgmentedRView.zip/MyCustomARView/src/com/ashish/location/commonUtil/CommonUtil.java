package com.ashish.location.commonUtil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Environment;
import android.text.TextUtils;
import android.widget.ImageView;

import com.raw.arview.R;

public class CommonUtil {
	
	
	/**
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isEmpty(String str) {

		try {
			if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str.trim())) {
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
		}
		return false;

	}
	
	/**
	 * @param email
	 *            Email Address to which to be verified
	 * 
	 * @return <code>true</code> if Email Address is valid<br/>
	 *         <code> false</code> if Email Address is invalid
	 */
	public static boolean isEmailValid(String email) {
		String emailAddress = email.toString().trim();

		if (TextUtils.isEmpty(emailAddress))
			return false;
		else if (emailAddress.length() <= 6)
			return false;
		else {

			CharSequence inputStr = emailAddress;
			String globalEmailAddressPattern = "[a-zA-Z0-9\\+\\.\\_\\%\\-\\+]{1,256}"
					+ "\\@"
					+ "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,64}"
					+ "("
					+ "\\."
					+ "[a-zA-Z0-9][a-zA-Z0-9\\-]{0,25}" + ")+";

			Pattern pattern = Pattern.compile(globalEmailAddressPattern);
			Matcher matcher = pattern.matcher(inputStr);
			if (matcher.matches())
				return true;
			else
				return false;
		}
		
		
	}
	/**
	 * 
	 * @return
	 */
	public static boolean isSdcardPresent() {
		return Environment.getExternalStorageState().equals(
				Environment.MEDIA_MOUNTED);
	}

	public static String[] getLatAndLong(Activity mContext) {
		LocationUtility mLocation = new LocationUtility(mContext);
		return new String[] { String.valueOf(mLocation.getCurrentLatitude()),
				String.valueOf(mLocation.getCurrentLongitude()),
				String.valueOf(mLocation.isGPSON()) };
	}
//	/**
//	 * 
//	 * @param aQuery
//	 * @param url
//	 * @param imageview
//	 * format for calling the function
//	 * CommonUtility.loadImage(new AQuery(act), url, holder.img_business);
//	 */
//	public static void loadImage(AQuery aQuery, String url, ImageView imageview) {
//
//		Bitmap bmp = aQuery.getCachedImage(url);
//		if (bmp != null) {
//			imageview.setImageBitmap(bmp);
//		} else
//			aQuery.id(imageview).image(url, true, true, 0, 0,
//					new BitmapAjaxCallback() {
//						@Override
//						protected void callback(String url, ImageView iv,
//								Bitmap bm, AjaxStatus status) {
//							if (bm == null)
//								iv.setImageResource(R.drawable.ic_launcher);
//							else {
//								iv.setImageBitmap(bm);
//							}
//						}
//					});
//	}
//	public static void loadImageForDetails(AQuery aQuery, String url, ImageView imageview) {
//
//		Bitmap bmp = aQuery.getCachedImage(url);
//		if (bmp != null) {
//			imageview.setImageBitmap(bmp);
//		} else
//			aQuery.id(imageview).image(url, true, true, 0, 0,
//					new BitmapAjaxCallback() {
//						@Override
//						protected void callback(String url, ImageView iv,
//								Bitmap bm, AjaxStatus status) {
//							if (bm == null)
//								iv.setImageResource(R.drawable.ic_launcher);
//							else {
//								iv.setImageBitmap(bm);
//							}
//						}
//					});
//	}
}
